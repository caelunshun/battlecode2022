package prototype2;

import battlecode.common.*;
import prototype2.comms.Archon;
import prototype2.comms.Communications;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

/**
 * The core robot class.
 *
 * We use composition to define robot behavior (rather than inheritance).
 * A robot contains a list of Attachments that can perform actions on each round.
 *
 * Multiple Attachments can be composed together to create compound behaviors. For
 * example, a robot can get one Attachment for movement and one for actions. The movement
 * attachment could be shared with other robot types, while the action attachment would
 * be specific to the robot type.
 */
public final class Robot {
    private RobotController rc;
    private List<Attachment> attachments = new ArrayList<>();
    private Communications comms;

    private List<Archon> friendlyArchons;
    private List<MapLocation> enemyArchons;

    private MapLocation homeArchon;
    private int homeArchonIndex;

    private Random random;

    private boolean endTurn = false;

    public Robot(RobotController rc) throws GameActionException {
        this.rc = rc;
        this.random = new Random(rc.getID());
        comms = new Communications(rc);

        for(Direction dir : Util.DIRECTIONS){
            if(rc.canSenseRobotAtLocation(rc.getLocation().add(dir))){
                RobotInfo info = rc.senseRobotAtLocation(rc.getLocation().add(dir));
                if(info.getType() == RobotType.ARCHON && info.getTeam() == rc.getTeam()){
                    homeArchon = info.location;
                    friendlyArchons = comms.readFriendlyArchons();
                    for (int i = 0; i < friendlyArchons.size(); i++) {
                        if (friendlyArchons.get(i).loc.equals(homeArchon)) {
                            homeArchonIndex = i;
                            break;
                        }
                    }
                    break;
                }
            }
        }
    }

    public void endTurn() {
        endTurn = true;
    }

    public RobotController getRc() {
        return rc;
    }

    public void run() {
        while(true) {
            try {
                rc.setIndicatorString("OK");
                update();
                doTurn();
            } catch (Exception e) {
                rc.setIndicatorString("ERROR - Exception");
                e.printStackTrace();;
            }
            Clock.yield();
        }
    }

    public void update() throws GameActionException {
        friendlyArchons = comms.readFriendlyArchons();
        enemyArchons = comms.readEnemyArchons();
        homeArchon = friendlyArchons.get(homeArchonIndex).loc;
    }

    private void doTurn() throws GameActionException {
        for (int i = 0; i < attachments.size(); i++) {
            Attachment attachment = attachments.get(i);
            attachment.doTurn();
            if (endTurn) {
                endTurn = false;
                return;
            }
        }
    }

    public void addAttachment(Attachment attachment) {
        attachments.add(attachment);
    }

    public void addAttachment(int i, Attachment attachment) {
        attachments.add(i, attachment);
    }

    public <T> T getAttachment(Class<T> type) {
        for (Attachment attachment : attachments) {
            if (attachment.getClass().equals(type)) {
                return (T) attachment;
            }
        }
        return null;
    }

    public List<Archon> getFriendlyArchons() {
        return friendlyArchons;
    }

    public List<MapLocation> getEnemyArchons() {
        return enemyArchons;
    }

    public MapLocation getHomeArchon(){
        return homeArchon;
    }

    public MapLocation getLeadArchon() {
        for (Archon archon : friendlyArchons) {
            if (archon.isLead && !archon.isDestroyed) {
                return archon.loc;
            }
        }
        return null;
    }

    public int getHomeArchonIndex() {
        return homeArchonIndex;
    }

    public void setHomeArchon(MapLocation loc) {
        homeArchon = loc;
    }

    public Communications getComms() {
        return comms;
    }

    private Direction moveRandomDirection;

    public void moveRandom() throws GameActionException {
        if (!rc.isMovementReady()) return;
        while (moveRandomDirection == null || !rc.canMove(moveRandomDirection)) {
            moveRandomDirection = Util.DIRECTIONS[random.nextInt(Util.DIRECTIONS.length)];
        }

        if (rc.canMove(moveRandomDirection)) {
            rc.move(moveRandomDirection);
        }
    }

    public Random getRng() {
        return random;
    }
}
