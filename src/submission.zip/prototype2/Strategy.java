package prototype2;

public enum Strategy {
    RUSH,
    TURTLE
}
