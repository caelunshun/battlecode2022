package prototype2;

import battlecode.common.GameActionException;
import battlecode.common.RobotController;
import battlecode.common.RobotType;
import prototype2.attachment.archon.BaseArchonAttachment;
import prototype2.attachment.builder.BuilderAttachment;
import prototype2.attachment.builder.SacrificeBuilderAttachment;
import prototype2.attachment.generic.*;
import prototype2.attachment.laboratory.LaboratoryAttachment;
import prototype2.attachment.miner.MinerAttachment;
import prototype2.attachment.miner.MinerDispersionAttachment;
import prototype2.attachment.sage.SageAttackAttachment;
import prototype2.attachment.sage.SageMicroAttachment;
import prototype2.attachment.soldier.SoldierMacroAttachment;
import prototype2.attachment.soldier.SoldierMicroAttachment;
import prototype2.attachment.watchtower.WatchtowerAttachment;

public class RobotBuilder {
    private final RobotType type;

    public RobotBuilder(RobotType type) {
        this.type = type;
    }

    public Robot build(RobotController rc) throws GameActionException {
        Robot robot = new Robot(rc);
        addAttachments(robot);
        return robot;
    }

    private void addAttachments(Robot robot) throws GameActionException  {
        robot.addAttachment(new RobotCounterAttachment(robot));
        robot.addAttachment(new EnemySpotterAttachment(robot));
        if (robot.getRc().getType() != RobotType.MINER) {
            robot.addAttachment(new LeadSpotterAttachment(robot));
        }
        robot.addAttachment(new ArchonSpotterAttachment(robot));
        switch (type) {
            case ARCHON:
                robot.addAttachment(new BaseArchonAttachment(robot));
                break;
            case MINER:
                robot.addAttachment(new SacrificeWhenLowAttachment(robot));
                robot.addAttachment(new MinerAttachment(robot));
                robot.addAttachment(new MinerDispersionAttachment(robot));
                break;
            case SAGE:
                robot.addAttachment(new SacrificeWhenLowAttachment(robot));
                robot.addAttachment(new SageMicroAttachment(robot));
                robot.addAttachment(new SoldierMacroAttachment(robot));
                break;
            case SOLDIER:
                robot.addAttachment(new AttackAttachment(robot));
                robot.addAttachment(new SacrificeWhenLowAttachment(robot));
                robot.addAttachment(new SoldierMicroAttachment(robot));
                robot.addAttachment(new SoldierMacroAttachment(robot));
                robot.addAttachment(new AttackAttachment(robot));
                break;
            case BUILDER:
                int numBuilders = robot.getComms().getNumRobots(RobotCategory.BUILDER);
                if (numBuilders >= BotConstants.MIN_BUILDERS
                    && (robot.getRc().getTeamLeadAmount(robot.getRc().getTeam()) < 1000 || numBuilders >= BotConstants.MAX_BUILDERS)) {
                    robot.addAttachment(new SacrificeBuilderAttachment(robot));
                } else {
                    robot.addAttachment(new BuilderAttachment(robot));
                }
                break;
            case WATCHTOWER:
                robot.addAttachment(new AttackAttachment(robot));
                robot.addAttachment(new WatchtowerAttachment(robot));
                break;
            case LABORATORY:
                robot.addAttachment(new LaboratoryAttachment(robot));
                break;
        }
    }
}
