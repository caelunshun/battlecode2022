package prototype1;

public class BotConstants {
    public static final int DEFENSE_MODE_TURN = 2022;
}
