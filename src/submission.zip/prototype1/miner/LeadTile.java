package prototype1.miner;

public class LeadTile {
    public int lastExhaustedRound = -10000;
    public boolean known = false;
}
