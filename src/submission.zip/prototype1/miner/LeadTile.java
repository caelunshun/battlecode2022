package prototype1.miner;

public class LeadTile {
    public int lastExhaustedRound = Integer.MIN_VALUE;
    public boolean known = false;
}
