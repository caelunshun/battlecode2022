package prototype1.comms;

public class LeadCounter {
}
