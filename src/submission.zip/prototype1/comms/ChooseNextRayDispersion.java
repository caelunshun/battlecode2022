package prototype1.comms;

public class ChooseNextRayDispersion{

    public ChooseNextRayDispersion(){

    }
}